A Pen created at CodePen.io. You can find this one at http://codepen.io/tutsplus/pen/QNeJgR.

 By [George Martsoukos](https://tutsplus.com/authors/george-martsoukos), read the [full tutorial on Envato Tuts+](http://webdesign.tutsplus.com/tutorials/building-a-vertical-timeline-with-css-and-a-touch-of-javascript--cms-26528).